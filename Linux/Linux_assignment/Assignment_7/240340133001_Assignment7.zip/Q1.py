#Write a program in python to convert Roman number to integer number.

def roman_to_int(roman):
    roman_map = {'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000}
    result = 0
    prev_value = 0

    for letter in roman[::-1]:
        value = roman_map.get(letter, 0)
        if value < prev_value:
            result -= value
        else:
            result += value
        prev_value = value

    return result


roman_numeral = input("Enter a Roman numeral: ").upper()


integer_numeral = roman_to_int(roman_numeral)

if integer_numeral != 0:
    print(f"The integer value of {roman_numeral} is: {integer_numeral}")
else:
    print("Invalid Roman numeral entered.")
