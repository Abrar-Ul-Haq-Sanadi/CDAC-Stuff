#write a python code to read the data of file and print it in reverse.

filename = "encodedata.txt"
with open(filename, "r") as file:
	encodedata = file.read().strip()

print("Encoded data read from file: ", encodedata)

decodedata = encodedata[::-1]
print("Decoded data: ", decodedata) 

