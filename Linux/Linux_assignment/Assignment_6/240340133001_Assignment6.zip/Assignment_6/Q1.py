year =int(input("Enter your year of passing"))
match year:
    case 2019:
        print("You graduated safely before covid")

    case 2020:
        print("You graduated in covid")

    case 2021:
        print("You graduated in covid")

    case 2022:
        print("You graduated in covid")
