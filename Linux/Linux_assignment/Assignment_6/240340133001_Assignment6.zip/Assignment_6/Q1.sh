echo "Enter you name"
read name

echo "Enter a year to check for sucsessful passout"
read year

case $year in
2019)
echo "Safely passout"
;;
2020)
echo "Covid passout"
;;
2021)
echo "Covid passout"
;;
2022)
echo "Covid passout"
;;
2023)
echo "Successfully Completed Degree"
;;
*)
echo "Invalid"
;;
esac
