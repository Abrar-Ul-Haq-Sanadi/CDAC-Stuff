#Write a shell script to calculate the sum of integers from 1 to n in loop.


#!/bin/bash


read -p "Enter a number (n): " n
sum=0


for (( i=1; i<=n; i++ ))
do
    sum=$((sum + i))
done


echo "The sum of integers from 1 to $n is: $sum"
