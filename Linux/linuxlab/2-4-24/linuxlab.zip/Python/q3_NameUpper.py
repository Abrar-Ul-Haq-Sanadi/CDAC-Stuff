n = input("enter your name\n")
print(n.lower())
