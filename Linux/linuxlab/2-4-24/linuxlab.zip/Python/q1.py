
print("enter a number")
n1 = int(input())
print("enter another number")
n2 = int(input())
m = n1 * n2
print("multiplication of n1 and n2 is ", m)

