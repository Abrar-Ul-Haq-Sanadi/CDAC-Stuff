n = int(input("Enter a number"))
if (n %2 == 0) :
	print(n,"is Even number")
else : 
	print(n,"is Odd number")
