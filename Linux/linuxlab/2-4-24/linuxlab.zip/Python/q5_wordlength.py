w = input("enter a word")
print("there are" +  str(len(w)) + " words")
