name = input("enter name\n")
age = int(input("enter age\n"))
print (name.upper())
print(age*2)
