n = input("enter a string:")
print(n + " is awesome")
