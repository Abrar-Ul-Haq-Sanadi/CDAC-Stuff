string = input("Enter a string: ")
#l=len(string)
for i in range (0,len(string)):
	print("character ",string[i], " is at" , "index",i)

