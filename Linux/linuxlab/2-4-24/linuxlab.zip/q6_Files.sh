for file in *
do
ls -l $file
done 
