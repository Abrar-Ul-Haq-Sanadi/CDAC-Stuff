def reverse():
	str1 = input("Enter a string: ")
	print(str1)
	str2 = str1[::-1]
	print(str2)

reverse()

