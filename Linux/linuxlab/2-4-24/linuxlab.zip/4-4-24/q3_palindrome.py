def palindrome():
	str1 = input("Enter a string: ")
	print(str)

	str2 = str1[::-1]
	print(str2)

	if (str1 == str2):
		print("Its Plaindrome")
	else :
		print("Not Palindromne")

palindrome()


