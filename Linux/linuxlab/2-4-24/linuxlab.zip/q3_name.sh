
echo "Hello user Enter your name"
read name
echo "$name Welcome to CDAC wishing you a great time ahead at cdac"
